#!/bin/bash

echo "Lo script bastardo.sh è in: 1"

