#!/bin/bash

rm files2/*

